//
//  Errors.swift
//  CGMHBot
//
//  Created by winlab on 2018/8/30.
//  Copyright © 2018 winlab. All rights reserved.
//

//import Foundation
//
//enum WeatherBotError: Error {
//    case unKnowIntent
//    case weatherManagerDictionary
//    case aiManagerDictionary
//    case geocodingManagerDictionary
//}
