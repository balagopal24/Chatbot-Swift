//
//  Message.swift
//  CGMHBot
//
//  Created by winlab on 2018/8/30.
//  Copyright © 2018 winlab. All rights reserved.
//

import UIKit

enum MessageType {
    case user
    case botText
}

class Message {
    
    var text: String = ""
    var date: Date
    var type: MessageType
   
    
    init(date: Date, type: MessageType) {
        self.date = date
        self.type = type
    }
    
  
    
    convenience init(text: String, date: Date, type: MessageType) {
        self.init(date: date, type: type)
        self.text = text
    }
    
    
    //MARK : return user or bot image
    func getImage() -> String {
        switch self.type {
        case .user:
            return "user.png"
        default:
            return "bot.pdf"
        }
    }

}
