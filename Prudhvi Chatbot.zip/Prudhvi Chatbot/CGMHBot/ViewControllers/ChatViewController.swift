//
//  ChatViewController.swift
//  CGMHBot
//
//  Created by winlab on 2018/8/30.
//  Copyright © 2018 winlab. All rights reserved.
//

import UIKit
import Toolbar
import SnapKit
import ReverseExtension
import Alamofire
import AVFoundation

class ChatViewController: UIViewController, UITextViewDelegate, UITableViewDataSource, UITableViewDelegate  {
    
    //tool bar
    let containerView = UIView()
    let toolbar: Toolbar = Toolbar()
    var textView: UITextView?
    var item0: ToolbarItem?
    var item1: ToolbarItem?
    var toolbarBottomConstraint: NSLayoutConstraint?
    var constraint: NSLayoutConstraint?
    var firstTime = true
    
    //Messages
    var tableView = UITableView()
    var messages = [Message]()
    
    var isMenuHidden: Bool = false {
        didSet {
            if oldValue == isMenuHidden {
                return
            }
            self.toolbar.layoutIfNeeded()
            UIView.animate(withDuration: 0.3) {
                self.toolbar.layoutIfNeeded()
            }
        }
    }
    
    override func loadView() {
        super.loadView()
        
        self.view.addSubview(containerView)
        containerView.snp.makeConstraints { (make) -> Void in
            make.bottom.equalTo(self.view.snp.bottomMargin)
            make.right.equalTo(self.view)
            make.left.equalTo(self.view)
            make.top.equalTo(self.view.snp.topMargin)
           
        }
        //setup background
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [UIColor.chatBackgroundEnd.cgColor, UIColor.chatBackgroundStart.cgColor]
        gradientLayer.locations = [0.0, 1.0]
        gradientLayer.frame = self.view.bounds
        containerView.layer.addSublayer(gradientLayer)
        
        //add tool bar
        containerView.addSubview(toolbar)
        self.toolbarBottomConstraint = self.toolbar.bottomAnchor.constraint(equalTo: containerView.bottomAnchor, constant: 0)
        self.toolbarBottomConstraint?.isActive = true
        let bottomView = UIView()
        bottomView.backgroundColor = .chatBackgroundEnd
        containerView.addSubview(bottomView)
        bottomView.snp.makeConstraints { (make) -> Void in
            make.right.equalTo(containerView)
            make.left.equalTo(containerView)
            make.top.equalTo(toolbar.snp.bottom)
            make.height.equalTo(100)
        }
        
        //add table view
        containerView.addSubview(tableView)
        tableView.snp.makeConstraints { (make) -> Void in
            make.bottom.equalTo(toolbar.snp.top)
            make.right.equalTo(containerView)
            make.left.equalTo(containerView)
            make.top.equalTo(containerView)
        }
       
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        print("begin viewDidLoad")

        //setup tool bar
        let textView: UITextView = UITextView(frame: .zero)
        textView.delegate = self
        textView.font = UIFont.systemFont(ofSize: 14)
        textView.backgroundColor = UIColor.black.withAlphaComponent(0.30)
        textView.textColor = .white
        self.textView = textView
        textView.layer.cornerRadius = 10
        item0 = ToolbarItem(customView: textView)
        item1 = ToolbarItem(title: "發信息", target: self, action: #selector(send))
        item1!.tintColor = .mainGreen
        item1!.setEnabled(true, animated: false)
        toolbar.setItems([item0!, item1!], animated: false)
        toolbar.backgroundColor = .black
        
        let toolbarWrapperView = UIView()
        toolbarWrapperView.backgroundColor = .grayBlue
        toolbar.insertSubview(toolbarWrapperView, at: 1)
        toolbarWrapperView.snp.makeConstraints { (make) -> Void in
            make.bottom.equalTo(toolbar)
            make.right.equalTo(toolbar)
            make.left.equalTo(toolbar)
            make.top.equalTo(toolbar)
        }
        
        let gestureRecognizer: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(hide))
        print("middle viewDidLoad")
        self.view.addGestureRecognizer(gestureRecognizer)
        
        //setup messages table view
        tableView.dataSource = self
        tableView.delegate = self
        tableView.re.delegate = self
        
        tableView.tableFooterView = UIView()
        tableView.register(UINib(nibName: "UserTableViewCell", bundle: nil), forCellReuseIdentifier: "UserTableViewCell")
        tableView.register(UINib(nibName: "TextResponseTableViewCell", bundle: nil), forCellReuseIdentifier: "TextResponseTableViewCell")
        tableView.estimatedRowHeight = 56
        tableView.separatorStyle = .none
        tableView.rowHeight = UITableViewAutomaticDimension
        tableView.backgroundColor = .clear
        
        
        tableView.re.scrollViewDidReachTop = { scrollView in
            print("scrollViewDidReachTop")
        }
        tableView.re.scrollViewDidReachBottom = { scrollView in
            print("scrollViewDidReachBottom")
        }
        print("false value",firstTime)
        //send welcome message
        if(firstTime) {
            print("inside if value",firstTime)
            sendWelcomeMessage()
            firstTime = false
        } else {
            print("inside else value",firstTime)
            let userQuery = textView.text!
            let responseText = getResponseForMessage(userQuery)
            print("responseText", responseText)
            let response = Message(text: responseText, date: Date(), type: .botText)
            self.sendMessage(response)
        }
//
        
    }

    override func didReceiveMemoryWarning() {
        print("inside didreceivememorywarning")
        super.didReceiveMemoryWarning()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        print("inside viewDidAppear")
        super.viewDidAppear(animated)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(notification:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(notification:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        print("inside viewDidDisAppear")
        super.viewDidDisappear(animated)
        NotificationCenter.default.removeObserver(self)
    }
    
    override func willTransition(to newCollection: UITraitCollection, with coordinator: UIViewControllerTransitionCoordinator) {
        self.toolbar.setNeedsUpdateConstraints()
    }
    
    // MARK: back button
      // MARK:- tableView
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return messages.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let message = messages[messages.count - (indexPath.row + 1)]
        
        switch message.type {
        case .user:
            print("inside usercell")
            let cell = tableView.dequeueReusableCell(withIdentifier: "UserTableViewCell", for: indexPath) as! UserTableViewCell
            cell.configure(with: message)
            return cell
        case .botText:
            print("inside bottext")
            let cell = tableView.dequeueReusableCell(withIdentifier: "TextResponseTableViewCell", for: indexPath) as! TextResponseTableViewCell
            cell.configure(with: message)
            return cell
        }
            
    }
    
    // Mark - Tool bar
    
    @objc func hide() {
        self.textView?.resignFirstResponder()
    }
    
    @objc final func keyboardWillShow(notification: Notification) {
        moveToolbar(up: true, notification: notification)
    }
    
    @objc final func keyboardWillHide(notification: Notification) {
        moveToolbar(up: false, notification: notification)
    }
    
    @objc func send() {
        print("inside send method")
        let userQuery = self.textView!.text!
        if self.textView!.text != "" {
            
            //user message
            let message = Message(text: userQuery, date: Date(), type: .user)
            self.sendMessage(message)
            
            //response message
            let responseText = getResponseForMessage(userQuery)
            print("responseText", responseText)
            let response = Message(text: responseText, date: Date(), type: .botText)
            self.sendMessage(response)
            speakText(responseText)
            
            //reset
            self.textView?.text = nil
            if let constraint: NSLayoutConstraint = self.constraint {
                self.textView?.removeConstraint(constraint)

            }
            self.toolbar.setNeedsLayout()
        }
    }
    
    // MARK:- send message
    func sendMessage(_ message: Message) {
        print("inside SendMessage",message)
        messages.append(message)
        tableView.beginUpdates()
        tableView.re.insertRows(at: [IndexPath(row: messages.count - 1, section: 0)], with: .automatic)
        tableView.endUpdates()
    }
    
    // MARK:- getResponse from PHP file
    func getResponseForMessage(_ statement: String) -> String {
        print("getResponseForMessage",statement)
        _ = statement.utf8
        // var encodedQuery = myQuery.stringByAddingPercentEncodingWithAllowedCharacters(NSUTF8StringEncoding)
        let myurl = "http://120.126.16.89/habibi.php?x="+statement
        print("myurl \(myurl)")
        let myurl2 = self.urlEncode(myurl)
        print("myurl2 \(myurl2)")
        
        let url = URL(string: myurl2)
        guard let myURL = URL(string: myurl2) else {
            print("Error: \(myurl) doesn't seem to be a valid URL")
            return "Not a valid URL"
        }
        var result = ""
        do {
            let myHTMLString = try String(contentsOf: myURL)
            print("here2",myHTMLString.utf8)
            result = myHTMLString
            print("reultarray",result)
        } catch let error {
            print("Error: \(error)")
        }
        return result
    }
    
    func urlEncode(_ string: String) -> String {
        return string.addingPercentEncoding(withAllowedCharacters: NSCharacterSet.urlQueryAllowed)!
    }
    
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        self.isMenuHidden = true
    }
    
    func textViewDidChange(_ textView: UITextView) {
        let size: CGSize = textView.sizeThatFits(textView.bounds.size)
        if let constraint: NSLayoutConstraint = self.constraint {
            textView.removeConstraint(constraint)
        }
        self.constraint = textView.heightAnchor.constraint(equalToConstant: size.height)
        self.constraint?.priority = UILayoutPriority.defaultHigh
        self.constraint?.isActive = true
    }

    final func moveToolbar(up: Bool, notification: Notification) {
        guard let userInfo = notification.userInfo else {
            return
        }
        let animationDuration: TimeInterval = (userInfo[UIKeyboardAnimationDurationUserInfoKey] as! NSNumber).doubleValue
        let keyboardHeight = up ? -(userInfo[UIKeyboardFrameEndUserInfoKey] as! NSValue).cgRectValue.height : 0
        
        // Animation
        self.toolbarBottomConstraint?.constant = keyboardHeight
        UIView.animate(withDuration: animationDuration, animations: {
            self.toolbar.layoutIfNeeded()
        }, completion: nil)
        self.isMenuHidden = up
    }
    
    //MARK:- SpeechAPI
    
    func speakText(_ statement:String) {
        let utterance = AVSpeechUtterance(string: statement)
        
        utterance.voice = AVSpeechSynthesisVoice(language: "zh-TW")
        utterance.rate = 0.45
        
        let synthesizer = AVSpeechSynthesizer()
        synthesizer.speak(utterance)
    }
    
    
    // MARK:- welcome message
    
    func sendWelcomeMessage() {
//        let firstTime = true
//        if firstTime {
        let welcomeMessage = "嗨，我是長庚寶，有什麼我可以服務您的嗎?"
        // messages.append(Message(date: Date(), text: , type: .answer))
        
        //let text = "Oh hello again Jon. I hope you’ve been well. What would you like to hear?"
        let message = Message(text: welcomeMessage, date: Date(), type: .botText)
        messages.append(message)
        speakText(welcomeMessage)
//        }
    }
}

